# [Title]

## Status

[Proposed | Accepted | Deprecated | Superseded]

## Context

[The issue or context that precipitated this decision.]

## Decision

[The decision that was made.]

## Consequences

[The results of the decision, both positive and negative.]
